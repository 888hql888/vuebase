<template>
  <div class="comment-wrapper">
    <div class="items">
      <div class="item">
        <div class="left">
          <img src="../assets/img/icon.jpg" alt="">
        </div>
        <div class="right">
          <div class="top">
            <span class='user'>阿木木:</span>
            <span class='content'>写歌的人假正经，唱歌的人最矫情，听歌的人最用心写歌的人假正经，唱歌的人最矫情，听歌的人最用心写歌的人假正经，唱歌的人最矫情，听歌的人最用心写歌的人假正经，唱歌的人最矫情，听歌的人最用心写歌的人假正经，唱歌的人最矫情，听歌的人最用心写歌的人假正经，唱歌的人最矫情，听歌的人最用心写歌的人假正经，唱歌的人最矫情，听歌的人最用心写歌的人假正经，唱歌的人最矫情，听歌的人最用心</span>
          </div>
          <div class="bottom">
            <div class="time">2016年9月18日</div>
            <div class="like-wrapper">
                <span>👍</span>(6666)
            </div>
          </div>
        </div>
      </div>
      <div class="item">
        <div class="left">
          <img src="../assets/img/icon.jpg" alt="">
        </div>
        <div class="right">
          <div class="top">
            <span class='user'>阿木木:</span>
            <span class='content'>写歌的人假正经，唱歌的人最矫情，听歌的人最用心写歌的人假正经，唱歌的人最矫情，听歌的人最用心写歌的人假正经，唱歌的人最矫情，听歌的人最用心写歌的人假正经，唱歌的人最矫情，听歌的人最用心写歌的人假正经，唱歌的人最矫情，听歌的人最用心写歌的人假正经，唱歌的人最矫情，听歌的人最用心写歌的人假正经，唱歌的人最矫情，听歌的人最用心写歌的人假正经，唱歌的人最矫情，听歌的人最用心</span>
          </div>
          <div class="bottom">
            <div class="time">2016年9月18日</div>
            <div class="like-wrapper">
                <span>👍</span>(6666)
            </div>
          </div>
        </div>
      </div>
      <div class="item">
        <div class="left">
          <img src="../assets/img/icon.jpg" alt="">
        </div>
        <div class="right">
          <div class="top">
            <span class='user'>阿木木:</span>
            <span class='content'>写歌的人假正经，唱歌的人最矫情，听歌的人最用心写歌的人假正经，唱歌的人最矫情，听歌的人最用心写歌的人假正经，唱歌的人最矫情，听歌的人最用心写歌的人假正经，唱歌的人最矫情，听歌的人最用心写歌的人假正经，唱歌的人最矫情，听歌的人最用心写歌的人假正经，唱歌的人最矫情，听歌的人最用心写歌的人假正经，唱歌的人最矫情，听歌的人最用心写歌的人假正经，唱歌的人最矫情，听歌的人最用心</span>
          </div>
          <div class="bottom">
            <div class="time">2016年9月18日</div>
            <div class="like-wrapper">
                <span>👍</span>(6666)
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
export default {

}
</script>

<style src="../assets/css/comment.css" scoped></style>