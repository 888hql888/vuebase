<template>
  <div class="video">
    <div class="title-wrapper">
      <span class='tag'>MV</span>
      <span class='title'>冲动的惩罚</span>
      <span class='artist'>刀郎</span>
    </div>
    <video src="" controls></video>
  </div>
</template>

<script>
export default {

}
</script>

<style src="../assets/css/video.css" scoped></style>