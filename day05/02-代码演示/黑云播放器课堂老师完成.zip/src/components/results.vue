<template>
  <div class="result-wrapper">
    <div class="song">
      <div class="name">
        <span class="iconfont icon-play"></span>
        美丽的神话
        <span class="iconfont icon-editmedia"></span>
      </div>
      <div class="singer">韩红|孙楠</div>
      <div class="album">《美丽的神话》</div>
      <div class="time">04:30</div>
    </div>
    <div class="song">
      <div class="name">
        <span class="iconfont icon-play"></span>
        美丽的神话
        <span class="iconfont icon-editmedia"></span>
      </div>
      <div class="singer">韩红|孙楠</div>
      <div class="album">《美丽的神话》</div>
      <div class="time">04:30</div>
    </div>
    <div class="song">
      <div class="name">
        <span class="iconfont icon-play"></span>
        美丽的神话
        <span class="iconfont icon-editmedia"></span>
      </div>
      <div class="singer">韩红|孙楠</div>
      <div class="album">《美丽的神话》</div>
      <div class="time">04:30</div>
    </div>
  </div>
</template>

<script>
export default {};
</script>

<style src="../assets/css/results.css" scoped></style>